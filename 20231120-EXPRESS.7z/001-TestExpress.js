let { MongoClient } = require('mongodb');
let express = require("express");
let app = express();

const cors = require('cors');



const gUrl = "mongodb+srv://corpascal:MONG01DB02@cluster0-rtxnf.gcp.mongodb.net?retryWrites=true&w=majority";
const gDbName = 'vincentDB';

// CORS Middleware
app.use(cors());


//----------------------------------------------------------------------------------------------
app.get("/getUsersList", (request, res) => {

    console.log(`${new Date().toISOString()} - app.get(/test) - début`);
    getUsersList().then((usersList) => {
        console.log(`${new Date().toISOString()} - app.get(/test) - send usersList`);
        res.send(usersList);
    },
        (error) => {
            console.log(`${new Date().toISOString()} - app.get(/test) - send []`);
            res.send([]);
        }
    );
});



//--------------------------------------------------------------------------------------------------------------------------
async function getUsersList() {

    return new Promise(async (resolve, reject) => {

        const client = new MongoClient(gUrl);
        await client.connect();
        const db = client.db(gDbName);
        const usersColl = db.collection('Users');
        const docs = await usersColl.find().toArray();

        client.close();
        resolve(docs);
    })
};


app.listen(8888);