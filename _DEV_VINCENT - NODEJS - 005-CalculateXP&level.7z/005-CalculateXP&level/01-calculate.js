for (let i = 0; i <= 100; i++) {
    let xpMin = Math.round(50 * (1 - (1.056) ** i) / (-0.056));
    let xpMax = Math.round(50 * (1 - (1.056) ** (i + 1)) / (-0.056)) - 1;
    console.log(`i=${i} - xpMin=${xpMin} - xpMax=${xpMax}`);
}