const fs = require('fs');
const https = require('https');

// permet l'utilisation d'un certificat auto-signé avec HTTPS
process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = 0;

let hostname = 'elentrepreneur96.bubbleapps.io';
let dataApi = '/version-test/api/1.1/obj';
let workflowApi = '/version-test/api/1.1/wf';

const rootPath = 'C:/_travail/__DEV_VINCENT/IKIGAI FINDER';
let filesMap = new Map();

start();

async function start() {

    console.log(`${new Date().toISOString()} - DEBUT`);

    let tablename = 'XPLevelReference';
    let records = [];
    let cursor = 0;
    let limit = 20;
    let bError = false;
    bRemaining = true;


    //--------------------------------------------------------------------------------------------------------
    while (!bError && bRemaining) {
        await getAllRecords(tablename, cursor, limit).then((response) => {
            response.results.map((e) => {
                records.push(e);
            });

            console.log(`${new Date().toISOString()} - start - response.count = ${response.count} - response.remaining = ${response.remaining}`);
            if (response.remaining > 0) {
                cursor += limit;
            } else {
                bRemaining = false;
            }
        }, (errMessage) => {
            console.log(`${new Date().toISOString()} - start - ERROR = ${errMessage}`);
            bError = true;
        });
    }


    //--------------------------------------------------------------------------------------------------------
    await Promise.all(records.map(async (e) => {
        await deleteRecord(tablename, e._id, e.level).then(() => {

        }, (errMessage) => {
            console.log(`${new Date().toISOString()} - start - ERROR = ${errMessage}`);
            bError = true;
        });
    }));

    let start = 0;
    let end = 100;

    for (let level = start; level <= end; level++) {
        let xpMin = Math.round(50 * (1 - (1.056) ** level) / (-0.056));
        let xpMax = Math.round(50 * (1 - (1.056) ** (level + 1)) / (-0.056)) - 1;
        console.log(`level=${level} - xpMin=${xpMin} - xpMax=${xpMax}`);

        await createRecord(tablename, level, xpMax, xpMin);
    }

    console.log(`${new Date().toISOString()} - FIN`);
}




//--------------------------------------------------------------------------------------------------------------
async function createRecord(tablename, level, xpMax, xpMin) {
    return new Promise((resolve, reject) => {

        let options = {
            hostname: 'elentrepreneur96.bubbleapps.io',
            path: `${dataApi}/${tablename}`,
            method: 'POST',
            headers: {
                'content-type': 'application/json'
            }
        }

        let data = [];
        let postReq = https.request(options, res => {
            res.on('data', chunk => {
                //console.log(`${new Date().toISOString()} - onData - chunk=${chunk}`);
                data.push(chunk);
            })

            res.on('end', () => {
                let result = JSON.parse(Buffer.concat(data).toString());
                if (result.error_class != undefined) {
                    console.log(`${new Date().toISOString()} - onEnd - REJECT result.error_class=${result.error_class}`);
                    reject(result.error_class);
                } else {
                    //console.log(`${new Date().toISOString()} - onEnd - resolve result.status=${result.status}`);
                    // console.log(`${new Date().toISOString()} - onEnd - resolve result.response=${result.response}`);
                    resolve(result);
                }
            })
        });

        postReq.on('error', err => {
            console.log(`${new Date().toISOString()} - onError - reject - ${err.message}`);
            reject(err.message);
        });

        let postData = {};
        postData.level = level;
        postData.xpMax = xpMax;
        postData.xpMin = xpMin;

        postReq.write(JSON.stringify(postData));
        postReq.end();
    });
}



//--------------------------------------------------------------------------------------------------------------
async function getAllRecords(tablename, cursor, limit) {
    return new Promise((resolve, reject) => {

        let options = {
            hostname: hostname,
            path: `${dataApi}/${tablename}?cursor=${cursor}&limit=${limit}`,
            method: 'GET',
            headers: {
                'content-type': 'application/json'
            }
        }

        let data = [];
        let req = https.request(options, res => {
            res.on('data', chunk => {
                //console.log(`${new Date().toISOString()} - onData - chunk=${chunk}`);
                data.push(chunk);
            })

            res.on('end', () => {
                let response = JSON.parse(Buffer.concat(data).toString());
                if (response.statusCode != undefined) {
                    reject(response.body.message);
                } else {
                    resolve(response.response);
                }
            })
        });

        req.on('error', err => {
            console.log(`${new Date().toISOString()} - getAllCPIkigaiPicture - onError - reject - ${err.message}`);
            reject(err.message);
        });

        req.end();
    });
}




//--------------------------------------------------------------------------------------------------------------
async function deleteRecord(tablename, id, level) {

    console.log(`${new Date().toISOString()} - deleteRecord(${id})`);

    return new Promise((resolve, reject) => {

        let options = {
            hostname: hostname,
            path: `${dataApi}/${tablename}/${id}`,
            method: 'DELETE',
            headers: {
                'content-type': 'application/json'
            }
        }

        let data = [];
        let deleteReq = https.request(options, res => {
            res.on('data', chunk => {
                data.push(chunk);
            })

            res.on('end', (res) => {
                let result = Buffer.concat(data).toString();
                if (result.statusCode != undefined) {
                    console.log(`${new Date().toISOString()} - onEnd - REJECT result.body.message=${result.body.message}`);
                    reject(result.body.message);
                } else {
                    // JSON.parse déclenche une exception si on transmet une chaine vide!
                    let jsonResult = result.length > 0 ? JSON.parse(result) : {};
                    console.log(`${new Date().toISOString()} - deleteRecord - onEnd - result=${JSON.stringify(jsonResult)}`);
                    resolve(jsonResult);
                }
            })
        });

        deleteReq.on('error', err => {
            console.log(`${new Date().toISOString()} - deleteRecord - onError - ${err.message}`);
            reject(err.message);
        });

        //if (level == 18 || level == 19) {
        deleteReq.end();
        //}
    });
}
