const { MongoClient } = require('mongodb');

console.log(`${new Date().toISOString()} - début`);

start();

console.log(`${new Date().toISOString()} - fin`);


//----------------------------------------------------------------------------------
async function start() {
    console.log(`${new Date().toISOString()} - start - début`);

    const url = "mongodb+srv://corpascal:MONG01DB02@cluster0-rtxnf.gcp.mongodb.net?retryWrites=true&w=majority";
    const client = new MongoClient(url);
    const dbName = 'vincentDB';

    await client.connect();
    const db = client.db(dbName);

    const usersColl = db.collection('Users');
    const docs = await usersColl.find().toArray();
    //const docs = await usersColl.find({ name: 'Bedros' }).toArray();

    docs.forEach((doc) => {
        console.log(`${new Date().toISOString()} - name=${doc.name}`);
    })


    console.log(`${new Date().toISOString()} - start - fin`);
    //process.exit(1);
}

