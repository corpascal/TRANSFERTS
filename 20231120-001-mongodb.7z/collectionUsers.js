[
    {
        "id": 1,
        "name": "Elon Musk",
        "lvl": 25,
        "ss": 5,
        "picture": "https://assets.pokemon.com/assets/cms2/img/pokedex/detail/001.png",
        "types": ["mentor", "Nakama"]
    }
]