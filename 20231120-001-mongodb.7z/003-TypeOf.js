let maDate = new Date();
let s1 = "12"; // 12
let i1 = 11; // "11"

s1 = s1 + i1;

console.log(`${maDate}`);
console.log(`${s1}`);
console.log(`type of s1 = ${typeof s1}`);
console.log(`type of i1 = ${typeof i1}`);

//console.log(`${new Date().toISOString()} - début`);
//console.log(`${new Date().toISOString()} - fin`);