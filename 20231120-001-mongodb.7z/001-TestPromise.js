

console.log(`${new Date().toISOString()} - début`);

start();

console.log(`${new Date().toISOString()} - fin`);


//----------------------------------------------------------------------------------
async function start() {
    console.log(`${new Date().toISOString()} - start - début`);
    //const result = await resolveAfter2Seconds();
    await resolveAfter2Seconds().then((result) => {
        console.log(`${new Date().toISOString()} - result=${result}`);
    },
        (error) => {
            console.log(`${new Date().toISOString()} - error=${error}`);
        });

    console.log(`${new Date().toISOString()} - start - fin`);
}

//----------------------------------------------------------------------------------
function resolveAfter2Seconds() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve('resolved');
            //reject('rejected');
        }, 2000);
    });
}