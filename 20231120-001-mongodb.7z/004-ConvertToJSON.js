const USERS = [
    {
        id: 1,
        name: "Elon Musk",
        lvl: 25,
        ss: 5,
        picture: "https://assets.pokemon.com/assets/cms2/img/pokedex/detail/001.png",
        types: ["mentor", "Nakama"],
        created: new Date()
    },
    {
        id: 2,
        name: "Jeff Bezos",
        lvl: 28,
        ss: 6,
        picture: "https://assets.pokemon.com/assets/cms2/img/pokedex/detail/004.png",
        types: ["Nakama", "Consultant"],
        created: new Date()
    },
    {
        id: 3,
        name: "Vincent",
        lvl: 21,
        ss: 4,
        picture: "https://assets.pokemon.com/assets/cms2/img/pokedex/detail/007.png",
        types: ["Nakama", "Vis ma Vie", "Mentor"],
        created: new Date()
    },
    {
        id: 4,
        name: "Tika",
        lvl: 16,
        ss: 2,
        picture: "https://assets.pokemon.com/assets/cms2/img/pokedex/detail/013.png",
        types: ["Nakama", "Freelance"],
        created: new Date()
    },
    {
        id: 5,
        name: "Bedros",
        lvl: 30,
        ss: 7,
        picture: "https://assets.pokemon.com/assets/cms2/img/pokedex/detail/016.png",
        types: ["Nakama", "Repas"],
        created: new Date()
    },
    {
        id: 6,
        name: "Miloude",
        lvl: 18,
        ss: 6,
        picture: "https://assets.pokemon.com/assets/cms2/img/pokedex/detail/019.png",
        types: ["Vis ma Vie", "Repas"],
        created: new Date()
    },
    {
        id: 7,
        name: "Justine",
        lvl: 14,
        ss: 5,
        picture: "https://assets.pokemon.com/assets/cms2/img/pokedex/detail/021.png",
        types: ["Nakama", "Coach"],
        created: new Date()
    },
    {
        id: 8,
        name: "Luc",
        lvl: 16,
        ss: 4,
        picture: "https://assets.pokemon.com/assets/cms2/img/pokedex/detail/023.png",
        types: ["Nakama"],
        created: new Date()
    },
    {
        id: 9,
        name: "Tothor",
        lvl: 21,
        ss: 7,
        picture: "https://assets.pokemon.com/assets/cms2/img/pokedex/detail/025.png",
        types: ["Electrik"],
        created: new Date()
    },
    {
        id: 10,
        name: "Oussama Amar",
        lvl: 19,
        ss: 3,
        picture: "https://assets.pokemon.com/assets/cms2/img/pokedex/detail/027.png",
        types: ["Formateur"],
        created: new Date()
    },
    {
        id: 11,
        name: "Donald Trump",
        lvl: 25,
        ss: 5,
        picture: "https://assets.pokemon.com/assets/cms2/img/pokedex/detail/035.png",
        types: ["Nakama", "Vis ma Vie"],
        created: new Date()
    },
    {
        id: 12,
        name: "Barack Obama",
        lvl: 17,
        ss: 8,
        picture: "https://assets.pokemon.com/assets/cms2/img/pokedex/detail/037.png",
        types: ["Nakama"],
        created: new Date()
    }
];

console.log(`${new Date().toISOString()} - tab=${JSON.stringify(USERS)}`);
