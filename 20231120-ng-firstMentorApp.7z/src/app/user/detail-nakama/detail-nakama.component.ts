import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
// import { USERS } from '../mock-user-list';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-detail-nakama',
  templateUrl: './detail-nakama.component.html'
})
export class DetailNakamaComponent implements OnInit {

userList : User[];
//User selected to detailed
user : User | undefined ; 

  constructor(
    private route: ActivatedRoute, 
    private router: Router,
    private userService: UserService
    ) { }

  ngOnInit() {
    // this.userList = USERS;
    const userId : string|null = this.route.snapshot.paramMap.get('id');
    //snapshot permet de connaitre l'url à instant T
    if (userId) {      
    this.userService.getUserById(+userId)
      .subscribe(user => this.user = user);

      // this.user = this.userService.getUserById(+userId);
    } 
    // console.log (`coucou ${this.user.name}`);
    console.log (`coucou ${userId}`);    
  }


  goToUserList(){
    this.router.navigate(['nakamas'])
  }

  goToEditUser(user : User){
    this.router.navigate(['edit/nakama',user.id])
  }


}

