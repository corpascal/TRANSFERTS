export class User {
    id: number;
    lvl: number;
    ss: number;
    name: string;
    picture: string;
    types: Array<string>;
    created: Date;
  }