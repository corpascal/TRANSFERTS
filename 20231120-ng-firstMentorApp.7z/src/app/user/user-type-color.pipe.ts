import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'userTypeColor'
})
export class UserTypeColorPipe implements PipeTransform {

  transform(type: string): string {
  
    let color: string;
  
    switch (type) {
      case 'Nakama':
        color = 'pink lighten-4';
        break;
      case 'Mentor':
        color = 'blue lighten-1';
        break;
      case 'Coach':
        color = 'deep-orange';
        break;
      case 'Consultant':
        color = 'green lighten-1';
        break;
      case 'Formateur':
        color = 'grey lighten-3';
        break;
      case 'Vis ma Vie':
        color = 'blue lighten-3';
        break;
      case 'Repas':
        color = 'deep-purple accent-1';
        break;
      case 'Freelance':
        color = 'lime accent-1';
        break;
      default:
        color = 'grey';
        break;
    }
  
    return 'chip ' + color;
  
  }
}

