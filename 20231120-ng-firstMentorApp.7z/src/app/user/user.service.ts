import { Injectable } from '@angular/core';
import { User } from './user';
import { USERS } from './mock-user-list';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, observable, of, tap } from 'rxjs';

@Injectable(
  // {providedIn: 'root'}
)
export class UserService {

  constructor(private http: HttpClient) { }

  //--------------------------------------------------------------------------------
  // getUserList(): Observable<User[]> {
  //   return this.http.get<User[]>('api/users').pipe(
  //     tap(
  //       (response) => {
  //         return this.log(response);
  //       }
  //     ),
  //     catchError((error) => this.handleError(error, []))
  //   );
  // }

  //--------------------------------------------------------------------------------
  getUserListV2() {
    //return of(USERS);
    return new Promise((resolve, reject) => {
      let url = `http://localhost:8888/getUsersList`;
      let observable: Observable<any> = this.http.get(url);

      observable.subscribe({
        next(res) {
          resolve(res);
        },
        error(err) {
          reject({ code: err.status, message: err.message });
        }
      });
    });
  }

  //--------------------------------------------------------------------------------
  getUserList() {
    //return of(USERS);

    let url = `http://localhost:8888/test`;
    let observable: Observable<any> = this.http.get(url);


    return observable;

    // return this.http.get<User[]>('api/users').pipe(
    //   tap(
    //     (response) => {
    //       return this.log(response);
    //     }
    //   ),
    //   catchError((error) => this.handleError(error, []))
    // );
  }

  // getUserList(): User[] {
  //   return USERS;
  // }


  // getUserById(userId: number): Observable<User | undefined> {
  //   return this.http.get<User>(`api/nakamas/${userId}`).pipe(
  //     tap((response) => this.log(response)),
  //     catchError((error) => this.handleError(error, undefined))
  //   );
  // }

  getUserById(userId: number): Observable<User | undefined> {

    // return of(USERS.find((user) => {
    //   return user.id == userId;
    // }));

    let userFound: User | undefined;

    for (let i = 0; i < USERS.length; i++) {
      if (USERS[i].id == userId) {
        userFound = USERS[i];
        break;
      }

    }
    return of(userFound);
  }


  // getUserById(userId:number) : User|undefined {
  //   return USERS.find(user => user.id == userId)
  // }

  private log(response: any) {
    console.table(response);
  }

  private handleError(error: Error, errorValue: any) {
    console.error(error);
    return of(errorValue)
  }


  getUserTypeList(): string[] {
    return [
      'Mentor',
      'Consultant',
      'Nakama',
      'Vis ma Vie',
      '',
      ''
    ]
  }
}
