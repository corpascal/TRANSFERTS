import { Component, OnInit } from '@angular/core';
import { USERS } from '../mock-user-list';
import { User } from '../user';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-list-nakama',
  templateUrl: './list-nakama.component.html'
})


export class ListNakamaComponent implements OnInit {
  userList: User[];
  // userList: User[] = USERS;


  constructor(
    private router: Router,
    private userService: UserService
  ) { }

  ngOnInit() {
    // this.userService.getUserList().subscribe((userList) => {
    //   console.log(`ListNakamaComponent - getUsersList - subscribe`);
    //   this.userList = userList
    // });

    this.userService.getUserListV2().then((res: User[]) => {
      this.userList = res;
    });

    // let observable = this.userService.getUserList();
    // observable.subscribe({
    //   next(res) {
    //     console.log(`ListNakamaComponent - getUsersList - subscribe next`);
    //     this.userList = res;
    //     console.log(`ListNakamaComponent - getUsersList - subscribe next - ${this.userList.length}`);
    //   },
    //   error(err) {
    //     console.log(`ListNakamaComponent - getUsersList - subscribe error - err=${JSON.stringify(err)}`);
    //   }
    // });


    // this.userList= this.userService.getUserList();
  }

  goToUserList(user: User) {
    this.router.navigate(['/nakama', user.id])
  }

}
