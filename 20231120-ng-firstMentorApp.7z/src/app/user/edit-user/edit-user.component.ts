import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { ActivatedRoute } from '@angular/router';
import { User } from '../user';

@Component({
  selector: 'app-edit-user',
  template: `
  <h2> Editer {{user?.name}}</h2>
  <p *ngIf="user" class="center">
      <img [src] ="user.picture">
  </p>
  <app-user-form *ngIf="user" [user]="user"></app-user-form>
  `,
  styles: [
  ]
})
export class EditUserComponent implements OnInit {

  user: User | undefined; 

  constructor(
    private route: ActivatedRoute, 
    private userService : UserService
  ) { }

  ngOnInit() {
    const userId : string|null = this.route.snapshot.paramMap.get('id');
    if (userId) {
      this.userService.getUserById(+userId)
      .subscribe(user => this.user = user);
      //  this.user = this.userService.getUserById(+userId);
      } else {
        this.user = undefined; 
      }
  
  }


  }
