import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListNakamaComponent } from './list-nakama/list-nakama.component';
import { DetailNakamaComponent } from './detail-nakama/detail-nakama.component';
import { BorderCardDirective } from './border-card.directive';
import { UserTypeColorPipe } from './user-type-color.pipe';
import { RouterModule, Routes } from '@angular/router';
import { UserService } from './user.service';
import { FormsModule } from '@angular/forms';
import { UserFormComponent } from './user-form/user-form.component';
import { EditUserComponent } from './edit-user/edit-user.component';

const userRoutes: Routes = [
  {path: 'edit/nakama/:id', component: EditUserComponent},
  {path: 'nakamas', component: ListNakamaComponent},
  {path: 'nakama/:id', component: DetailNakamaComponent}
  ];


@NgModule({
  declarations: [
    ListNakamaComponent, 
    DetailNakamaComponent,
    BorderCardDirective,
    UserTypeColorPipe,
    UserFormComponent,
    EditUserComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule.forChild(userRoutes)
  ],
  providers: [UserService],
})
export class UserModule { }
