import { Injectable } from '@angular/core';
import {InMemoryDbService} from 'angular-in-memory-web-api'
import { USERS } from './user/mock-user-list';

@Injectable({
  providedIn: 'root'
})
export class InMemoryDataService implements InMemoryDbService{


createDb() {
  const users = USERS
  return { users };
}


  constructor() { }
}
