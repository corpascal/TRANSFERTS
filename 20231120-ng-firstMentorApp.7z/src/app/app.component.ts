import { Component, OnInit } from '@angular/core';
// import { USERS } from './mock-user-list'; 
// import { User } from './user';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html'
})
export class AppComponent {

// implements OnInit{
  // userList: User[] = USERS;
  // userSelected  : User | undefined;

  // ngOnInit() {
  //   console.table(this.userList);
  // }

  // selectUser(userId: string) {
  //const user : User|undefined = this.userList.find(user => user.id == +userId);
  //   const user : User|undefined = this.userList.find((user) => {
  //     return user.id == +userId;
  // });
    
  //   if(user) {
  //     console.log(`vous avez demandé le mentor ${user.name}`);
  //     this.userSelected=user;
  //   } else {
  //     console.log(`votre mentor n'existe pas`);
  //     this.userSelected= user;
  //   }
  // }  

  // selectUser(event : MouseEvent) {
  //   const index : number = +(event.target as HTMLInputElement).value;
  //   console.log(`vous avez cliqué sur le mentor ${this.userList[index].name}`);
  // }  
  
  // selectUser(user : User) {
  //   console.log(`vous avez cliqué sur le mentor ${user.name}`);
  // }
}
