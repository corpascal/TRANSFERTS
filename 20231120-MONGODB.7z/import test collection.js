[
	{ "username": "corvincent"},
	{ "username": "corpascal"}
]